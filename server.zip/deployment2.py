import math
import shutil
from osgeo import gdal
from osgeo import osr
import cv2
import numpy as np
import gdal2tiles
import os

# 3屏电脑：D:/apache-tomcat-8.5.99/webapps/tiles
# outputTilesPath = 'D:/apache-tomcat-8.5.99/webapps/tiles'
# outputTifFileName = 'C:/workspace/cesiumChooseDot/server/output.tif'
# tifFileDir = "C:/workspace/cesiumChooseDot/server/data/"
# 自己测试
outputTilesPath = 'C:/tools/apache-tomcat-8.5.82/webapps1/tiles'
outputTifFileName = 'C:/workspace/cesiumChooseDot/server/output.tif'
tifFileDir = "C:/workspace/lbc/txc/0226/"
class deploy():
    #一张tif的大小为3000*4000左右的栅格，计算每个栅格的网速作为通信态势
    def __init__(self, tifname, radioposs):
        self.dsmPath = tifname
        #读入tif
        dsm_gdal = gdal.Open(tifname)
        dsm_array = dsm_gdal.GetRasterBand(1).ReadAsArray()
        geotransform = dsm_gdal.GetGeoTransform()  # 图像得仿射变换参数

        self.imgCellWidth = geotransform[1]  # 像元宽度
        self.imgCellHeight = -geotransform[5]  # 像元高度,需要加一个负号
        self.imgWidth = dsm_gdal.RasterXSize  # 图像列数
        self.imgHeight = dsm_gdal.RasterYSize  # 图像行数
        self.size = np.array([self.imgHeight, self.imgWidth, 300])
        # 读取上下左右坐标
        #输出结果：(496960.28080999607, 3317599.907954256) (598467.7295418619, 3434063.5611976646)
        # self.imgLeftUpX = 496960.28080999607
        # self.imgLeftUpY = 3434063.5611976646
        # self.imgRightDownX = 598467.7295418619
        # self.imgRightDownY = 3317599.907954256
        self.imgLeftUpX = geotransform[0]  # 左上角横坐标
        self.imgLeftUpY = geotransform[3]  # 左上角纵坐标
        self.imgRightDownX = self.imgLeftUpX + self.imgWidth * self.imgCellWidth + self.imgHeight * geotransform[2]  # 右下角横坐标
        self.imgRightDownY = self.imgLeftUpY - self.imgHeight * self.imgCellHeight + self.imgWidth * geotransform[4]  # 右下角纵坐标
        # 保存dsm句柄
        self.imgArray = dsm_array
        self.imgGdal = dsm_gdal
        # 保存radiopos
        self.radioposs = radioposs
        self.radioposMeter = []
        self.radioposGrid = []
        for radio in radioposs:
            meterpos = self.latlng2meter(radio)
            meterpos = [meterpos[0], meterpos[1], radio[2]]
            gridpos  = self.meterPos2GridPos(meterpos[0], meterpos[1], radio[2])
            self.radioposGrid.append(gridpos)
            self.radioposMeter.append(meterpos)
        print("radio lon,lat:",self.radioposs)
        # print("radio meter:",self.radioposMeter)
        # print("radio grid:",self.radioposGrid)

    def meter2Grid(self, X, Y):
        i = math.floor((self.imgLeftUpY - Y) / self.imgCellHeight) + 1
        j = math.floor((X - self.imgLeftUpX) / self.imgCellWidth) + 1
        i = max(min(i, self.size[0] - 1), 0)
        j = max(min(j, self.size[1] - 1), 0)
        return i, j

    def meterPos2GridPos(self, X, Y, Z):
        i = math.floor((self.imgLeftUpY - Y) / self.imgCellHeight)+1
        j = math.floor((X - self.imgLeftUpX) / self.imgCellWidth)+1
        i = max(min(i, self.size[0]-1), 0)
        j = max(min(j, self.size[1]-1), 0)
        h = math.floor( Z / 10) + 1
        return i, j, h
    def calculatePixel2Radio(self, i, j, ri, rj, rh):
        return 0
    def getNetSpeed3d(self, point1, point2) -> float:
        # 1.直线栅格化
        grids, dis = self.getGridInLine(point1, point2)
        total = grids.shape[0]
        if total <= 1:
            return 1
        if dis > 500:
            return 0
        # 2.判断高度以及坐标是否经过建筑并记录个数
        count = 0
        for i in range(total):
            if self.imgArray[grids[i][0]][grids[i][1]] >= (grids[i][2]-1)*10:
                count += 1
        # 3.以直线总长除以栅格数量表示每个栅格长度
        d_undergroud = count / total
        d_notundergroud = 1 - d_undergroud
        return d_notundergroud

    def gridPos2meterPos(self, i, j):
        x = self.imgLeftUpX + j * self.imgCellWidth
        y = self.imgLeftUpY - i * self.imgCellHeight
        z = self.imgArray[i][j]
        return x, y, z



    def meter2latlng(self, metercoor):
        # X,Y -> lon, lat
        prosrs = osr.SpatialReference()  # 空间参考，源数据是SpatialReference
        prosrs.ImportFromWkt(self.imgGdal.GetProjection())  # dataset.GetProjection()源结果CGCS2000 PROJCS["CGCS2000_3_Degree_GK_CM_117E",GEOGCS["China Geodetic Coordinate System 2000",DATUM["China_2000",SPHEROID["CGCS2000",6378137,298.257222101004,AUTHORITY["EPSG","1024"]],AUTHORITY["EPSG","1043"]],PRIMEM["Greenwich",0],UNIT["degree",0.0174532925199433,AUTHORITY["EPSG","9122"]],AUTHORITY["EPSG","4490"]],PROJECTION["Transverse_Mercator"],PARAMETER["latitude_of_origin",0],PARAMETER["central_meridian",117],PARAMETER["scale_factor",1],PARAMETER["false_easting",500000],PARAMETER["false_northing",0],UNIT["metre",1,AUTHORITY["EPSG","9001"]],AXIS["Easting",EAST],AXIS["Northing",NORTH],AUTHORITY["EPSG","4548"]]
        # geosrs = prosrs.CloneGeogCS()
        source_projection = osr.SpatialReference()
        source_projection.ImportFromEPSG(4326)
        ct = osr.CoordinateTransformation(prosrs, source_projection  )
        if metercoor[1]< 3000000:
            coords = ct.TransformPoint(metercoor[1], metercoor[0])  # 源结果 (211938.94312448334, 3379371.4904014003, 0.0)
        else:
            coords = ct.TransformPoint(metercoor[0], metercoor[1])  # 源结果 (211938.94312448334, 3379371.4904014003, 0.0)
        if coords[1] > coords[0]:
            return [coords[1], coords[0]]
        else:
            return coords[:2]



    def latlng2meter(self, radiopos):
        prosrs = osr.SpatialReference()  # 空间参考，源数据是SpatialReference
        prosrs.ImportFromWkt(self.imgGdal.GetProjection())  # dataset.GetProjection()源结果CGCS2000 PROJCS["CGCS2000_3_Degree_GK_CM_117E",GEOGCS["China Geodetic Coordinate System 2000",DATUM["China_2000",SPHEROID["CGCS2000",6378137,298.257222101004,AUTHORITY["EPSG","1024"]],AUTHORITY["EPSG","1043"]],PRIMEM["Greenwich",0],UNIT["degree",0.0174532925199433,AUTHORITY["EPSG","9122"]],AUTHORITY["EPSG","4490"]],PROJECTION["Transverse_Mercator"],PARAMETER["latitude_of_origin",0],PARAMETER["central_meridian",117],PARAMETER["scale_factor",1],PARAMETER["false_easting",500000],PARAMETER["false_northing",0],UNIT["metre",1,AUTHORITY["EPSG","9001"]],AXIS["Easting",EAST],AXIS["Northing",NORTH],AUTHORITY["EPSG","4548"]]

        source_projection = osr.SpatialReference()
        source_projection.ImportFromEPSG(4326) 
        ct = osr.CoordinateTransformation(source_projection, prosrs)
        coords = ct.TransformPoint(radiopos[1], radiopos[0])  # 源结果 (211938.94312448334, 3379371.4904014003, 0.0)
        if coords[0] > coords[1]:
            return [coords[1], coords[0]]
        else:
            return coords[:2]

    def getGridInLine(self, point1, point2):
        v = point2 - point1
        grids = np.empty(shape=(0, point1.shape[0]), dtype ='uint8')
        dis = np.linalg.norm(v, ord=2)
        if dis >500:
            return grids, 501
        step = 1.0
        curlength = 0
        while curlength < dis:
            curlength += step
            tp = np.clip(np.fix(point1 + v * curlength / dis + 0.5).reshape(1, point1.shape[0]), 0, self.size-1).astype(np.int32)
            grids = np.append(grids, tp, axis=0)
        grids = np.unique(grids, axis=0)
        return grids, dis


    def grid2latlon(self, i, j):
        x, y, _ = self.gridPos2meterPos(i, j)
        return self.meter2latlng([x, y])

    def GetLineNetSpeed(self, X1, Y1, Z1, endRow, endCol, Z2): #栅格坐标
        building_Penetrate_Distance = 0
        tree_Penetrate_Distance = 0

        X2, Y2, _ = self.gridPos2meterPos(endRow, endCol) # 测试点
        startRow, startCol, _ = self.meterPos2GridPos(X1, Y1, Z1) # 电台点

        if X1 == X2 and Y1 == Y2:
            return [0, 0]

        # [startRow, startCol, hj, df] = Point2Ras(X1, Y1, self.imgLeftUpX,self.imgLeftUpY,self.imgWidth,self.imgHeight,self.imgArray)
        # [endRow, endCol, hjhg, ghhg] = Point2Ras(X2, Y2, self.imgLeftUpX,self.imgLeftUpY,self.imgWidth,self.imgHeight, self.imgArray)
        Current_Z = Z1

        l = math.sqrt((X1 - X2) * (X1 - X2) + (Y1 - Y2) * (Y1 - Y2) + (Z1 - Z2) * (Z1 - Z2))

        if abs((X1 - X2) / self.imgCellWidth) > abs((Y1 - Y2) / self.imgCellHeight):
            k = (Y2 - Y1) / (X2 - X1);  # 斜率

            d = abs(endCol - startCol);  # 相差的列数
            if d == 0:
                d = 1
            # 每个栅格平摊的高程和线段长度

            divide_Z = (Z1 - Z2) / d
            divide_S = l / d

            if endCol > startCol:
                for i in range(d):
                    tmpCol = startCol + i
                    tmpRow = math.floor(startRow - i * k)

                    Current_Z = Current_Z - divide_Z
                    # 如果DSM的栅格的高度大于或等于当前栅格的高度，可以认为线段通过了DSM该栅格的部分
                    if self.imgArray[tmpRow][tmpCol] >= Current_Z:
                        tree_Penetrate_Distance = tree_Penetrate_Distance + divide_S

            else:
                for i in range(d):
                    tmpCol = startCol - i
                    tmpRow = math.floor(startRow + i * k)

                    Current_Z = Current_Z - divide_Z

                    if self.imgArray[tmpRow][tmpCol] >= Current_Z:
                        tree_Penetrate_Distance = tree_Penetrate_Distance + divide_S

        else:
            k = (X2 - X1) / (Y2 - Y1)  # 斜率

            d = abs(endRow - startRow)  # 相差的行数
            if d == 0:
                d = 1
            # 每个栅格平摊的高程和线段长度
            divide_Z = (Z1 - Z2) / d
            divide_S = l / d

            if endRow > startRow:
                for i in range(d):
                    tmpRow = startRow + i
                    tmpCol = math.floor(startCol - i * k)

                    Current_Z = Current_Z - divide_Z

                    if self.imgArray[tmpRow][tmpCol] >= Current_Z:
                        tree_Penetrate_Distance = tree_Penetrate_Distance + divide_S

            else:
                for i in range(d):
                    tmpRow = startRow - i
                    tmpCol = math.floor(startCol + i * k)

                    Current_Z = Current_Z - divide_Z

                    if self.imgArray[tmpRow][tmpCol] >= Current_Z:
                        tree_Penetrate_Distance = tree_Penetrate_Distance + divide_S

        arr = [l - tree_Penetrate_Distance, tree_Penetrate_Distance]
        return arr

    def main(self):
        radiaArea = 100
        result = np.ones(shape=self.size[:2])
        result *= -1
        for count in range(len(self.radioposMeter)):
            radiopixel = self.radioposGrid[count]


            imin = max(0, radiopixel[0]-radiaArea)
            imax = min(self.imgHeight-1, radiopixel[0]+radiaArea)
            jmin = max(0, radiopixel[1]-radiaArea)
            jmax = min(self.imgWidth-1, radiopixel[1]+radiaArea)
            for i in range(imin, imax, 1):
                for j in range(jmin, jmax, 1):
                    dis = (i-radiopixel[0])*(i-radiopixel[0])+(j-radiopixel[1])*(j-radiopixel[1])
                    times = 1
                    pixelHeight = self.imgArray[i][j]
                    if pixelHeight < 0:
                        continue
                        pixelHeight = 5
                    if dis > radiaArea*radiaArea:
                        continue
                    times = 1- math.sqrt(dis) / radiaArea
                    # for calculateRadio in self.radioposMeter:    
                    value = self.GetLineNetSpeed(self.radioposMeter[count][0], self.radioposMeter[count][1], self.radioposMeter[count][2], i, j, pixelHeight)
                    speed = (40-0.05*value[1]) * times
                    speed = max(0, speed)
                    if speed > result[i][j]:
                        result[i][j] = speed
            result[radiopixel[0]][radiopixel[1]] = 0
        array_color = self.drawColor(result)
        # self.tilesResult(array_color)
        self.drawResult(array_color, '')
        return result

    def main2(self): #根据电台为中心生成多个图片
        radiaArea = 100
        rectangles = []
        for count in range(len(self.radioposMeter)):
            result = np.ones(shape=(2 * radiaArea, 2 * radiaArea))
            result *= -1
            radiopixel = self.radioposGrid[count]
            imin = max(0, radiopixel[0] - radiaArea)
            imax = min(self.imgHeight - 1, radiopixel[0] + radiaArea-1)
            jmin = max(0, radiopixel[1] - radiaArea)
            jmax = min(self.imgWidth - 1, radiopixel[1] + radiaArea-1)
            #计算要放的矩形范围
            west_south = self.grid2latlon(imax, jmin)
            east_north = self.grid2latlon(imin, jmax)
            rectangles.append(west_south+east_north)
            for i in range(imin, imax+1, 1):
                for j in range(jmin, jmax+1, 1):
                    dis = (i - radiopixel[0]) * (i - radiopixel[0]) + (j - radiopixel[1]) * (j - radiopixel[1])
                    pixelHeight = self.imgArray[i][j]
                    if pixelHeight < 0:
                        continue
                        pixelHeight = 5
                    if dis > radiaArea*radiaArea:
                        continue
                    times = 1 - math.sqrt(dis) / radiaArea
                    # for calculateRadio in self.radioposMeter:
                    value = self.GetLineNetSpeed(self.radioposMeter[count][0], self.radioposMeter[count][1],
                                                 self.radioposMeter[count][2], i, j, pixelHeight)
                    speed = (40 - 0.05 * value[1]) * times
                    speed = max(0, speed)
                    if speed > result[i-imin][j-jmin]:
                        result[i-imin][j-jmin] = speed
            result[99][99] = 0
            array_color = self.drawColor(result)
            self.drawResult(array_color, str(count))
        return rectangles


    def drawResult(self, result, label):
        # displaying the image
        cv2.imwrite("C:/workspace/cesiumChooseDot/server/resultimg_db/result_img"+ label + ".png", result)

    def drawColor(self, result):
        shape = result.shape
        array_created = np.full((shape[0], shape[1], 3), 255, dtype=np.uint8)
        for i in range(shape[0]):
            for j in range(shape[1]):
                if result[i][j]>=0 and result[i][j] < 8:
                    array_created[i, j] = [0, 0, 255]
                    pass
                elif result[i][j] >= 8 and result[i][j] < 16:
                    array_created[i, j] = [255, 0, 255]
                    pass
                elif result[i][j] >= 16 and result[i][j] < 24:
                    array_created[i, j] = [64,125,255]
                    pass
                elif result[i][j] >= 24 and result[i][j] < 32:
                    array_created[i, j] = [255, 0, 0]
                    pass
                elif result[i][j] >= 32:
                    array_created[i, j] = [0, 252, 124]
                    pass
        return array_created

    def tilesResult(self, data):
        min_level = 5
        max_level = 13 # 5-15的用时太久了，要将近8min

        # 设置驱动和文件名
        driver = gdal.GetDriverByName('GTiff')

        # 创建新的TIF文件
        dataset = driver.Create(outputTifFileName, self.imgWidth, self.imgHeight, 3, gdal.GDT_Byte)

        # 设置几何信息和投影信息
        dataset.SetGeoTransform(self.imgGdal.GetGeoTransform())
        dataset.SetProjection(self.imgGdal.GetProjection())


        # 为每个波段生成随机数据并写入
        for i in range(1, 4):
            band = dataset.GetRasterBand(i)
            band.WriteArray(data[:,:,3-i])

        # 关闭数据集
        dataset = None

        options = {
            'zoom':(min_level,max_level), # 切片层级 min zoom 5 - max zoom 18
            'resume':True,
            'tile_size': 256, # 瓦片大小
            # 's_srs': 'PROJCS["CGCS2000 / 3-degree Gauss-Kruger CM 114E",GEOGCS["China Geodetic Coordinate System 2000",DATUM["China_2000",SPHEROID["CGCS2000",6378137,298.257222101,AUTHORITY["EPSG","1024"]],AUTHORITY["EPSG","1043"]],PRIMEM["Greenwich",0,AUTHORITY["EPSG","8901"]],UNIT["degree",0.0174532925199433,AUTHORITY["EPSG","9122"]],AUTHORITY["EPSG","4490"]],PROJECTION["Transverse_Mercator"],PARAMETER["latitude_of_origin",0],PARAMETER["central_meridian",114],PARAMETER["scale_factor",1],PARAMETER["false_easting",500000],PARAMETER["false_northing",0],UNIT["metre",1,AUTHORITY["EPSG","9001"]],AXIS["Northing",NORTH],AXIS["Easting",EAST],AUTHORITY["EPSG","4547"]]',
            's_srs': self.imgGdal.GetProjection(),
            'xyz': True,
            'np_processes':2
        }
        if os.path.exists(outputTilesPath):  # 3屏电脑：D:/apache-tomcat-8.5.99/webapps/tiles
            shutil.rmtree(outputTilesPath)
        gdal2tiles.generate_tiles(outputTifFileName, outputTilesPath, **options)
        self.changeName(outputTilesPath)
        
    def changeName(self, dir):
        levels = os.listdir(dir)
        levels = [name for name in levels if os.path.isdir(os.path.join(dir, name))]
        for level in levels:
            dir1 = dir+'/'+level
            level1 = os.listdir(dir1)
            for director in level1:
                dir2 = dir1+'/'+director
                level2 = os.listdir(dir2)
                for pic in level2:
                    strs = pic.split('.')
                    if strs[1] == 'png':
                        oldname = int(strs[0])
                        newname = str(pow(2,int(level))-1 - oldname)+'.png'
                        os.rename(os.path.join(dir2, pic), os.path.join(dir2, newname))


class Particle:
    def __init__(self, dim, bounds):
        #self.position = np.random.uniform(bounds[0], bounds[1], dim)  # 初始化粒子位置

        x_coords = np.random.uniform(bounds[0][0], bounds[1][0], dim)
        y_coords = np.random.uniform(bounds[0][1], bounds[1][1], dim)

        # 将点的坐标按照所需的格式组织成一个NumPy数组
        self.position = np.empty(2 * dim)
        self.position[::2] = x_coords
        self.position[1::2] = y_coords

        self.velocity = np.random.uniform(-1, 1, 2 *dim)  # 初始化粒子速度
        self.best_position = self.position.copy()  # 记录粒子历史最佳位置
        self.best_score = float('inf')  # 记录粒子历史最佳得分

def objective_function(x):
    # 这是一个示例的目标函数，你可以根据需要修改
    return np.sum(np.square(x))

def update_velocity(particle, global_best_position, w, c1, c2):
    r1 = np.random.rand(len(particle.velocity))
    r2 = np.random.rand(len(particle.velocity))
    inertia = w * particle.velocity  # 惯性项
    cognitive = c1 * r1 * (particle.best_position - particle.position)  # 认知项
    social = c2 * r2 * (global_best_position - particle.position)  # 社会项
    particle.velocity = inertia + cognitive + social  # 更新粒子速度

def update_position(particle, bounds):
    particle.velocity[particle.velocity>50] = 50
    particle.velocity[particle.velocity < -50] = -50
    particle.position += particle.velocity  # 更新粒子位置
    # 确保粒子位置在边界内
    particle.position[::2] = np.clip(particle.position[::2], bounds[0][0], bounds[1][0])
    particle.position[1::2] = np.clip(particle.position[1::2], bounds[0][1], bounds[1][1])

def dfs(node, visited, adjacency_list):
    visited[node] = True
    for neighbor in adjacency_list[node]:
        if not visited[neighbor]:
            dfs(neighbor, visited, adjacency_list)

def pso(radioposs,Y, bounds, num_particles, max_iter, w, c1, c2,h_uav,h_ground,num_uav,num_ground ,tifFilePath, aa):
    # aa = deploy(tifFilePath, radioposs)
    dim = num_uav+num_ground
    particles = [Particle(dim, bounds) for _ in range(num_particles)]  # 初始化粒子群
    global_best_position = None
    global_best_score = float('inf')
    length = len(radioposs)
    #print((-Y[1]+a.imgRightDownY)//a.imgCellHeight)
    adjacency_list_final = {}
    for _ in range(max_iter):
        for particle in particles:
            score = 0
            score_total=0
            dis_total=0

            # 建立一个图，使用dfs判断是否为连通图
            # 构建邻接列表
            num_nodes = length + num_uav + num_ground
            adjacency_list = {i: [] for i in range(num_nodes)}
            # nodes1为所有点的grid表示，height为所有点的高度
            nodes1 = np.array([[aa.meter2Grid(row[0], row[1])[0], aa.meter2Grid(row[0], row[1])[1]] for row in Y]).flatten()
            nodes1 = np.concatenate((nodes1, particle.position))
            nodes1 = nodes1.astype(int)
            height = np.zeros(num_nodes)
            for i in range(length):
                height[i] = Y[i, 2]
            height[length:length + num_uav] = h_uav
            # uav高度改为比地面高
            for i in range(length, length + num_uav):
                height[i] = h_uav + aa.imgArray[nodes1[i * 2]][nodes1[i * 2] + 1]
            #ground高度改为比地面高
            for i in range(length + num_uav,length + num_uav+num_ground):
                height[i] = h_ground+aa.imgArray[nodes1[i * 2]][nodes1[i * 2]+1]
            for i in range(num_nodes):
                for j in range(i + 1, num_nodes):
                    value = aa.GetLineNetSpeed(aa.gridPos2meterPos(nodes1[i * 2], nodes1[i * 2 + 1])[0],
                                               aa.gridPos2meterPos(nodes1[i * 2], nodes1[i * 2 + 1])[1], height[i],
                                               nodes1[j * 2], nodes1[j * 2 + 1], height[j])
                    dis = (nodes1[i * 2] - nodes1[j * 2]) ** 2 + (nodes1[i * 2 + 1] - nodes1[j * 2 + 1]) ** 2
                    times = 1 - math.sqrt(dis) / 100
                    #通视怎么办
                    if ((i>=length and i<length+num_uav) and (j>=length and j<length+num_uav)) and math.sqrt(dis)<1736: #如果i和j都是无人机，并且两者距离小于50km，并且被挡的距离等于0（即通视）
                        adjacency_list[i].append(j)
                        adjacency_list[j].append(i)
                        continue
                    #score = (40 - 0.05 * value[1]) * times
                    if (40 - 0.05 * value[1]) * times > 8 and times>0:
                        adjacency_list[i].append(j)
                        adjacency_list[j].append(i)
            # 使用深度优先搜索来检查连通性
            visited = [False] * num_nodes
            dfs(0, visited, adjacency_list)

            # 如果所有节点都被访问到，则说明是连通图
            for item in visited:
                if item==True:
                    score=score-1

            '''
            for index in range(length):
                value = aa.GetLineNetSpeed(Y[index, 0], Y[index, 1], Y[index, 2], i, j, h)
                dis = (aa.radioposGrid[index][0] - i) ** 2 + (aa.radioposGrid[index][1] - j) ** 2
                dis_total+=math.sqrt(dis)/100000
                times = 1 - math.sqrt(dis) / 100
                score = (40 - 0.05 * value[1]) * times
                if (40 - 0.05 * value[1]) * times > 8:
                    score = 8
                    score_total-=score
                if times < 0 or score < 8:
                    score_total = 0

            if score_total!=-length*8:
                score_total=0
            '''



            #score=score_total+dis_total
            #score=math.sqrt(dis)
            if score < particle.best_score:
                particle.best_score = score
                particle.best_position = particle.position.copy()
                adjacency_list_final = adjacency_list
            if score < global_best_score:
                global_best_score = score
                global_best_position = particle.position.copy()

        for particle in particles:
            update_velocity(particle, global_best_position, w, c1, c2)
            update_position(particle, bounds)

    return global_best_position, global_best_score, adjacency_list_final



# tifFilePath = r"C:\workspace\lbc\txc\0226\wuhan_dsm_114.tif"


if __name__ == '__main__':
    import matplotlib
    matplotlib.use('agg')
    tifFilePath = r"C:\workspace\lbc\txc\0226\wuhan_dsm_114_dsmCGCS2k.tif"
    # radioposs = [[114.705261, 30.520493, 50.0]]
    radioposs = [[114.356454,
30.527542,
36.91],[
        114.422254,
        30.520955,
        30.96
    ]]
    # radioposs = [[114.356403
    # 30.527544]]
    # radioposs = [[110.285157, 25.219959, 146.09], [110.326391, 25.257717, 148.35]]


#[4015,3525]
    a = deploy(tifFilePath, radioposs)
    a.main2()
    # test = [432136.21134040295, 2793644.6384706534, 200.0]
    #
    # print(a.meter2latlng(test))

    #方法一：
    # a.depart9()
    #方法二：
    # st = time.time()
    # results = a.main()
    # et = time.time()
    # print("用时：", et - st)
    # # for i in range(len(results)):
    # a.drawResult(results, "1716")
    # # cmap = matplotlib.colormaps['coolwarm']
    # #
    # # plt.imshow(result, cmap)
    # # plt.colorbar()
    # # plt.savefig(r"C:\workspace\lbc\txc\0226\test1111.png")
    # print(result[result==1].shape)
    # print(result.shape)
    # print(result)

    leftup = [496992.6730883496347815,3433606.7595169977284968]
    rightdown = [598469.4938060842687264,3318023.9410257339477539]

    leftdown = [497008.1,3318036.0]
    rightdown = [598448.7,3433597.0]

    #cesiumlab 影像切片经纬度范围  
    #输出结果：(496960.28080999607, 3317599.907954256) (598467.7295418619, 3434063.5611976646)
    b = [113.968503,29.977322]
    c = [115.031259,31.023744]
    #cesiumlab 地形切片经纬度范围   
    b = [113.968306,29.976969] #(496941.2578756226, 3317560.78241345)
    c = [115.031233,31.023760] #(598465.2303981915, 3434065.3122185073)

    # result = a.main()
    # print(result)

